/**
 * 
 */
/**
 * @author �ɶ�
 *
 */
module text6 {
	requires java.desktop;
	requires javafx.graphics;
}